#!/bin/bash
set -euo pipefail

JOB="${1:?Usage: run_spark_job.sh <job_filename.py>}"
JOB_PATH="/opt/spark-jobs/${JOB}"

/opt/spark/bin/spark-submit \
  --master local[*] \
  --driver-memory 2g \
  --executor-memory 2g \
  --packages org.postgresql:postgresql:42.7.3,com.clickhouse:clickhouse-jdbc:0.6.3 \
  "${JOB_PATH}"
