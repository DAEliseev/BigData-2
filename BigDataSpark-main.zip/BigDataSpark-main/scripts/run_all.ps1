$ErrorActionPreference = "Stop"

Write-Host "Starting Docker stack..."
docker compose up -d --build

Write-Host "Waiting for PostgreSQL..."
Start-Sleep -Seconds 20

Write-Host "Running ETL to star schema..."
docker exec lab2-spark /opt/spark/bin/spark-submit --master "local[*]" --driver-memory 2g /opt/spark-jobs/01_etl_star_schema.py

Write-Host "Running ClickHouse reports..."
docker exec lab2-spark /opt/spark/bin/spark-submit --master "local[*]" --driver-memory 2g /opt/spark-jobs/02_reports_clickhouse.py

