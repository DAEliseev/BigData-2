import os


def env(name: str, default: str) -> str:
    return os.getenv(name, default)


POSTGRES = {
    "host": env("POSTGRES_HOST", "localhost"),
    "port": env("POSTGRES_PORT", "5432"),
    "database": env("POSTGRES_DB", "labdb"),
    "user": env("POSTGRES_USER", "lab"),
    "password": env("POSTGRES_PASSWORD", "lab"),
}

CLICKHOUSE = {
    "host": env("CLICKHOUSE_HOST", "localhost"),
    "port": env("CLICKHOUSE_PORT", "8123"),
    "database": env("CLICKHOUSE_DB", "labdb"),
    "user": env("CLICKHOUSE_USER", "lab"),
    "password": env("CLICKHOUSE_PASSWORD", "lab"),
}


def postgres_jdbc_url() -> str:
    p = POSTGRES
    return f"jdbc:postgresql://{p['host']}:{p['port']}/{p['database']}"


def postgres_properties() -> dict:
    p = POSTGRES
    return {"user": p["user"], "password": p["password"], "driver": "org.postgresql.Driver"}


def clickhouse_jdbc_url() -> str:
    c = CLICKHOUSE
    return (
        f"jdbc:clickhouse://{c['host']}:{c['port']}/{c['database']}"
        f"?ssl=false&compress=0"
    )


def clickhouse_properties() -> dict:
    c = CLICKHOUSE
    return {"user": c["user"], "password": c["password"], "driver": "com.clickhouse.jdbc.ClickHouseDriver"}
