from __future__ import annotations

import json
from datetime import datetime
from typing import Dict

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from config import postgres_jdbc_url, postgres_properties


def read_dw_table(spark: SparkSession, table: str) -> DataFrame:
    return (
        spark.read.format("jdbc")
        .option("url", postgres_jdbc_url())
        .option("dbtable", table)
        .options(**postgres_properties())
        .load()
    )


def load_star_schema(spark: SparkSession) -> Dict[str, DataFrame]:
    return {
        "fact": read_dw_table(spark, "dw.fact_sales"),
        "date": read_dw_table(spark, "dw.dim_date"),
        "customer": read_dw_table(spark, "dw.dim_customer"),
        "seller": read_dw_table(spark, "dw.dim_seller"),
        "product": read_dw_table(spark, "dw.dim_product"),
        "store": read_dw_table(spark, "dw.dim_store"),
        "supplier": read_dw_table(spark, "dw.dim_supplier"),
    }


def sales_enriched(tables: Dict[str, DataFrame]) -> DataFrame:
    f = tables["fact"].alias("f")
    joined = (
        f.join(tables["date"].alias("d"), "date_key")
        .join(tables["customer"].alias("c"), "customer_key")
        .join(tables["product"].alias("p"), "product_key")
        .join(tables["store"].alias("st"), "store_key")
        .join(tables["supplier"].alias("su"), "supplier_key")
    )
    return joined.select(
        "sale_id",
        "date_key",
        "customer_key",
        "product_key",
        "store_key",
        "supplier_key",
        F.col("f.sale_quantity").alias("sale_quantity"),
        F.col("f.sale_total_price").alias("sale_total_price"),
        F.col("f.product_price").alias("product_price"),
        "year",
        "month",
        "month_name",
        "customer_id",
        "first_name",
        "last_name",
        "country",
        "product_id",
        "product_name",
        "product_category",
        "product_rating",
        "product_reviews",
        "store_name",
        "store_city",
        "store_country",
        "supplier_name",
        "supplier_country",
    )


def _to_json_rows(df: DataFrame) -> str:
    rows = [row.asDict() for row in df.collect()]
    for row in rows:
        for key, value in list(row.items()):
            if hasattr(value, "isoformat"):
                row[key] = value.isoformat()
            elif value is not None and not isinstance(value, (str, int, float, bool)):
                row[key] = str(value)
    return json.dumps(rows, ensure_ascii=False)


def build_all_marts(spark: SparkSession) -> Dict[str, Dict[str, str]]:
    tables = load_star_schema(spark)
    sales = sales_enriched(tables)
    generated_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    top10_products = (
        sales.groupBy("product_id", "product_name", "product_category")
        .agg(
            F.sum("sale_quantity").alias("total_quantity"),
            F.sum("sale_total_price").alias("total_revenue"),
            F.count("sale_id").alias("sales_count"),
        )
        .orderBy(F.desc("total_quantity"))
        .limit(10)
    )

    revenue_by_category = sales.groupBy("product_category").agg(
        F.sum("sale_total_price").alias("total_revenue"),
        F.sum("sale_quantity").alias("total_quantity"),
    )

    product_ratings = sales.groupBy("product_id", "product_name").agg(
        F.avg("product_rating").alias("avg_rating"),
        F.sum("product_reviews").alias("total_reviews"),
        F.sum("sale_quantity").alias("total_sold"),
    )

    customer_totals = sales.groupBy("customer_id", "first_name", "last_name", "country").agg(
        F.sum("sale_total_price").alias("total_spent"),
        F.count("sale_id").alias("orders_count"),
    )

    top10_customers = customer_totals.orderBy(F.desc("total_spent")).limit(10)

    customers_by_country = sales.groupBy("country").agg(
        F.countDistinct("customer_id").alias("customers_count"),
        F.sum("sale_total_price").alias("total_revenue"),
    )

    avg_check_per_customer = customer_totals.withColumn(
        "avg_check", F.col("total_spent") / F.col("orders_count")
    )

    monthly_yearly = sales.groupBy("year", "month", "month_name").agg(
        F.sum("sale_total_price").alias("revenue"),
        F.sum("sale_quantity").alias("quantity"),
        F.count("sale_id").alias("orders"),
    )

    yearly_trend = sales.groupBy("year").agg(
        F.sum("sale_total_price").alias("revenue"),
        F.sum("sale_quantity").alias("quantity"),
        F.count("sale_id").alias("orders"),
    ).orderBy("year")

    monthly_yearly_trends = monthly_yearly.withColumn("granularity", F.lit("monthly")).unionByName(
        yearly_trend.withColumn("month", F.lit(None).cast("int"))
        .withColumn("month_name", F.lit(None).cast("string"))
        .withColumn("granularity", F.lit("yearly"))
    ).withColumn(
        "_ord",
        F.when(F.col("granularity") == "yearly", F.lit(13)).otherwise(F.col("month")),
    ).orderBy(
        "year",
        "_ord",
    ).drop("_ord")

    revenue_period_comparison = yearly_trend.withColumn(
        "prev_year_revenue",
        F.lag("revenue").over(Window.partitionBy().orderBy("year")),
    ).withColumn(
        "revenue_change_pct",
        F.when(
            F.col("prev_year_revenue").isNotNull() & (F.col("prev_year_revenue") != 0),
            (F.col("revenue") - F.col("prev_year_revenue")) / F.col("prev_year_revenue") * 100,
        ),
    )

    avg_order_by_month = sales.groupBy("year", "month", "month_name").agg(
        F.avg("sale_total_price").alias("avg_order_size"),
        F.count("sale_id").alias("orders"),
    ).orderBy("year", "month")

    store_stats = sales.groupBy(
        "store_key", "store_name", "store_city", "store_country"
    ).agg(
        F.sum("sale_total_price").alias("total_revenue"),
        F.count("sale_id").alias("orders_count"),
    )

    top5_stores = store_stats.orderBy(F.desc("total_revenue")).limit(5)

    sales_by_city_country = sales.groupBy("store_city", "store_country").agg(
        F.sum("sale_total_price").alias("total_revenue"),
        F.count("sale_id").alias("orders_count"),
    )

    avg_check_per_store = store_stats.withColumn(
        "avg_check", F.col("total_revenue") / F.col("orders_count")
    )

    supplier_stats = sales.groupBy(
        "supplier_key", "supplier_name", "supplier_country"
    ).agg(
        F.sum("sale_total_price").alias("total_revenue"),
        F.avg("product_price").alias("avg_product_price"),
        F.sum("sale_quantity").alias("total_quantity"),
    )

    top5_suppliers = supplier_stats.orderBy(F.desc("total_revenue")).limit(5)

    avg_price_by_supplier = supplier_stats.select(
        "supplier_name", "supplier_country", "avg_product_price", "total_revenue"
    )

    sales_by_supplier_country = sales.groupBy("supplier_country").agg(
        F.sum("sale_total_price").alias("total_revenue"),
        F.sum("sale_quantity").alias("total_quantity"),
    )

    product_quality = sales.groupBy("product_id", "product_name").agg(
        F.avg("product_rating").alias("avg_rating"),
        F.sum("product_reviews").alias("total_reviews"),
        F.sum("sale_quantity").alias("total_sold"),
        F.sum("sale_total_price").alias("total_revenue"),
    )

    rating_extremes = {
        "highest_rated": _to_json_rows(
            product_quality.orderBy(F.desc("avg_rating")).limit(10)
        ),
        "lowest_rated": _to_json_rows(
            product_quality.orderBy(F.asc("avg_rating")).limit(10)
        ),
    }

    corr_df = product_quality.select(
        F.corr("avg_rating", "total_sold").alias("rating_quantity_correlation"),
        F.corr("avg_rating", "total_revenue").alias("rating_revenue_correlation"),
    )

    most_reviewed = product_quality.orderBy(F.desc("total_reviews")).limit(10)

    return {
        "mart_product_sales": {
            "generated_at": generated_at,
            "top10_products": _to_json_rows(top10_products),
            "revenue_by_category": _to_json_rows(revenue_by_category),
            "product_ratings": _to_json_rows(product_ratings),
        },
        "mart_customer_sales": {
            "generated_at": generated_at,
            "top10_customers": _to_json_rows(top10_customers),
            "customers_by_country": _to_json_rows(customers_by_country),
            "avg_check_per_customer": _to_json_rows(avg_check_per_customer),
        },
        "mart_time_sales": {
            "generated_at": generated_at,
            "monthly_yearly_trends": _to_json_rows(monthly_yearly_trends),
            "revenue_period_comparison": _to_json_rows(revenue_period_comparison),
            "avg_order_size_by_month": _to_json_rows(avg_order_by_month),
        },
        "mart_store_sales": {
            "generated_at": generated_at,
            "top5_stores": _to_json_rows(top5_stores),
            "sales_by_city_country": _to_json_rows(sales_by_city_country),
            "avg_check_per_store": _to_json_rows(avg_check_per_store),
        },
        "mart_supplier_sales": {
            "generated_at": generated_at,
            "top5_suppliers": _to_json_rows(top5_suppliers),
            "avg_price_by_supplier": _to_json_rows(avg_price_by_supplier),
            "sales_by_supplier_country": _to_json_rows(sales_by_supplier_country),
        },
        "mart_product_quality": {
            "generated_at": generated_at,
            "rating_extremes": json.dumps(rating_extremes, ensure_ascii=False),
            "rating_sales_correlation": _to_json_rows(corr_df),
            "most_reviewed_products": _to_json_rows(most_reviewed),
        },
    }
