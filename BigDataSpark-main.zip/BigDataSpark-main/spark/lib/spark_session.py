from typing import Optional

from pyspark.sql import SparkSession


def build_spark(app_name: str, extra_packages: Optional[str] = None) -> SparkSession:
    packages = extra_packages or (
        "org.postgresql:postgresql:42.7.3,"
        "com.clickhouse:clickhouse-jdbc:0.6.3"
    )
    return (
        SparkSession.builder.appName(app_name)
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY")
        .config("spark.jars.packages", packages)
        .getOrCreate()
    )
