from __future__ import annotations

from typing import Dict

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from config import POSTGRES, postgres_jdbc_url, postgres_properties


def clear_dw_tables(spark: SparkSession) -> None:
    jvm = spark.sparkContext._jvm
    jvm.Class.forName("org.postgresql.Driver")
    url = postgres_jdbc_url()
    conn = jvm.java.sql.DriverManager.getConnection(
        url, POSTGRES["user"], POSTGRES["password"]
    )
    stmt = conn.createStatement()
    stmt.execute(
        "TRUNCATE TABLE dw.fact_sales, dw.dim_date, dw.dim_customer, "
        "dw.dim_seller, dw.dim_product, dw.dim_store, dw.dim_supplier "
        "RESTART IDENTITY CASCADE"
    )
    stmt.close()
    conn.close()


def read_mock_data(spark: SparkSession) -> DataFrame:
    return (
        spark.read.format("jdbc")
        .option("url", postgres_jdbc_url())
        .option("dbtable", "staging.mock_data")
        .options(**postgres_properties())
        .load()
    )


def write_table(df: DataFrame, table: str) -> None:
    (
        df.write.format("jdbc")
        .option("url", postgres_jdbc_url())
        .option("dbtable", table)
        .options(**postgres_properties())
        .mode("append")
        .save()
    )


def build_dim_date(mock: DataFrame) -> DataFrame:
    parsed = mock.withColumn("sale_date_parsed", F.to_date(F.col("sale_date"), "M/d/yyyy"))
    return (
        parsed.select("sale_date_parsed")
        .distinct()
        .withColumnRenamed("sale_date_parsed", "full_date")
        .withColumn("date_key", F.date_format("full_date", "yyyyMMdd").cast("int"))
        .withColumn("year", F.year("full_date"))
        .withColumn("month", F.month("full_date"))
        .withColumn("day", F.dayofmonth("full_date"))
        .withColumn("quarter", F.quarter("full_date"))
        .withColumn("month_name", F.date_format("full_date", "MMMM"))
        .select("date_key", "full_date", "year", "month", "day", "quarter", "month_name")
    )


def build_dim_customer(mock: DataFrame) -> DataFrame:
    return (
        mock.select(
            F.col("sale_customer_id").alias("customer_id"),
            F.col("customer_first_name").alias("first_name"),
            F.col("customer_last_name").alias("last_name"),
            F.col("customer_age").alias("age"),
            F.col("customer_email").alias("email"),
            F.col("customer_country").alias("country"),
            F.col("customer_postal_code").alias("postal_code"),
            F.col("customer_pet_type").alias("pet_type"),
            F.col("customer_pet_name").alias("pet_name"),
            F.col("customer_pet_breed").alias("pet_breed"),
        )
        .dropDuplicates(["customer_id"])
    )


def build_dim_seller(mock: DataFrame) -> DataFrame:
    return (
        mock.select(
            F.col("sale_seller_id").alias("seller_id"),
            F.col("seller_first_name").alias("first_name"),
            F.col("seller_last_name").alias("last_name"),
            F.col("seller_email").alias("email"),
            F.col("seller_country").alias("country"),
            F.col("seller_postal_code").alias("postal_code"),
        )
        .dropDuplicates(["seller_id"])
    )


def build_dim_product(mock: DataFrame) -> DataFrame:
    return (
        mock.select(
            F.col("sale_product_id").alias("product_id"),
            "product_name",
            "product_category",
            F.col("product_price").cast("decimal(12,2)"),
            F.col("product_quantity").cast("int"),
            "pet_category",
            F.col("product_weight").cast("decimal(12,2)"),
            "product_color",
            "product_size",
            "product_brand",
            "product_material",
            "product_description",
            F.col("product_rating").cast("decimal(4,2)"),
            F.col("product_reviews").cast("int"),
            F.to_date(F.col("product_release_date"), "M/d/yyyy").alias("product_release_date"),
            F.to_date(F.col("product_expiry_date"), "M/d/yyyy").alias("product_expiry_date"),
        )
        .dropDuplicates(["product_id"])
    )


def build_dim_store(mock: DataFrame) -> DataFrame:
    return (
        mock.select(
            "store_name",
            "store_location",
            "store_city",
            "store_state",
            "store_country",
            "store_phone",
            "store_email",
        )
        .dropDuplicates(["store_name", "store_city", "store_country"])
    )


def build_dim_supplier(mock: DataFrame) -> DataFrame:
    return (
        mock.select(
            "supplier_name",
            "supplier_contact",
            "supplier_email",
            "supplier_phone",
            "supplier_address",
            "supplier_city",
            "supplier_country",
        )
        .dropDuplicates(["supplier_name", "supplier_country"])
    )


def _with_surrogate_key(df: DataFrame, key_col: str) -> DataFrame:
    w = Window.orderBy(F.monotonically_increasing_id())
    return df.withColumn(key_col, F.row_number().over(w))


def build_fact_sales(mock: DataFrame, dims: Dict[str, DataFrame]) -> DataFrame:
    base = mock.withColumn("full_date", F.to_date(F.col("sale_date"), "M/d/yyyy")).withColumn(
        "date_key", F.date_format("full_date", "yyyyMMdd").cast("int")
    )

    dim_customer = dims["customer"].select(
        F.col("customer_key"),
        F.col("customer_id"),
    )
    dim_seller = dims["seller"].select(F.col("seller_key"), F.col("seller_id"))
    dim_product = dims["product"].select(F.col("product_key"), F.col("product_id"))
    dim_store = dims["store"].select(
        F.col("store_key"),
        "store_name",
        "store_city",
        "store_country",
    )
    dim_supplier = dims["supplier"].select(
        F.col("supplier_key"),
        "supplier_name",
        "supplier_country",
    )

    joined = (
        base.alias("m")
        .join(dim_customer.alias("c"), F.col("m.sale_customer_id") == F.col("c.customer_id"))
        .join(dim_seller.alias("s"), F.col("m.sale_seller_id") == F.col("s.seller_id"))
        .join(dim_product.alias("p"), F.col("m.sale_product_id") == F.col("p.product_id"))
        .join(
            dim_store.alias("st"),
            (F.col("m.store_name") == F.col("st.store_name"))
            & (F.col("m.store_city") == F.col("st.store_city"))
            & (F.col("m.store_country") == F.col("st.store_country")),
        )
        .join(
            dim_supplier.alias("su"),
            (F.col("m.supplier_name") == F.col("su.supplier_name"))
            & (F.col("m.supplier_country") == F.col("su.supplier_country")),
        )
    )

    return joined.select(
        F.col("m.row_id").alias("sale_id"),
        F.col("m.date_key"),
        F.col("c.customer_key"),
        F.col("s.seller_key"),
        F.col("p.product_key"),
        F.col("st.store_key"),
        F.col("su.supplier_key"),
        F.col("m.sale_quantity").cast("int"),
        F.col("m.sale_total_price").cast("decimal(12,2)"),
        F.col("m.product_price").cast("decimal(12,2)"),
    )


def run_star_etl(spark: SparkSession) -> None:
    clear_dw_tables(spark)
    mock = read_mock_data(spark)

    dim_date = build_dim_date(mock)
    dim_customer = _with_surrogate_key(build_dim_customer(mock), "customer_key")
    dim_seller = _with_surrogate_key(build_dim_seller(mock), "seller_key")
    dim_product = _with_surrogate_key(build_dim_product(mock), "product_key")
    dim_store = _with_surrogate_key(build_dim_store(mock), "store_key")
    dim_supplier = _with_surrogate_key(build_dim_supplier(mock), "supplier_key")

    dims = {
        "customer": dim_customer,
        "seller": dim_seller,
        "product": dim_product,
        "store": dim_store,
        "supplier": dim_supplier,
    }
    fact_sales = build_fact_sales(mock, dims)

    write_table(dim_date, "dw.dim_date")
    write_table(dim_customer, "dw.dim_customer")
    write_table(dim_seller, "dw.dim_seller")
    write_table(dim_product, "dw.dim_product")
    write_table(dim_store, "dw.dim_store")
    write_table(dim_supplier, "dw.dim_supplier")
    write_table(fact_sales, "dw.fact_sales")
