#!/usr/bin/env python3
import sys

sys.path.insert(0, "/opt/spark-lib")

from etl_star import run_star_etl
from spark_session import build_spark


def main() -> None:
    spark = build_spark("lab2-etl-star-schema")
    try:
        run_star_etl(spark)
    finally:
        spark.stop()


if __name__ == "__main__":
    main()
