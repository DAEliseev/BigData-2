#!/usr/bin/env python3
import sys

from pyspark.sql import Row

sys.path.insert(0, "/opt/spark-lib")

from config import CLICKHOUSE, clickhouse_jdbc_url, clickhouse_properties
from reports_builder import build_all_marts
from spark_session import build_spark

MART_COLUMNS = {
    "mart_product_sales": [
        "generated_at",
        "top10_products",
        "revenue_by_category",
        "product_ratings",
    ],
    "mart_customer_sales": [
        "generated_at",
        "top10_customers",
        "customers_by_country",
        "avg_check_per_customer",
    ],
    "mart_time_sales": [
        "generated_at",
        "monthly_yearly_trends",
        "revenue_period_comparison",
        "avg_order_size_by_month",
    ],
    "mart_store_sales": [
        "generated_at",
        "top5_stores",
        "sales_by_city_country",
        "avg_check_per_store",
    ],
    "mart_supplier_sales": [
        "generated_at",
        "top5_suppliers",
        "avg_price_by_supplier",
        "sales_by_supplier_country",
    ],
    "mart_product_quality": [
        "generated_at",
        "rating_extremes",
        "rating_sales_correlation",
        "most_reviewed_products",
    ],
}


def write_mart_to_clickhouse(spark, table: str, payload: dict) -> None:
    columns = MART_COLUMNS[table]
    row = Row(**{col: payload[col] for col in columns})
    df = spark.createDataFrame([row], schema=",".join(f"{c} string" for c in columns))

    (
        df.write.format("jdbc")
        .option("url", clickhouse_jdbc_url())
        .option("dbtable", f"{CLICKHOUSE['database']}.{table}")
        .options(**clickhouse_properties())
        .mode("append")
        .save()
    )


def main() -> None:
    spark = build_spark("lab2-reports-clickhouse")
    try:
        marts = build_all_marts(spark)
        for table, payload in marts.items():
            write_mart_to_clickhouse(spark, table, payload)
    finally:
        spark.stop()


if __name__ == "__main__":
    main()
