# \# Лабораторная работа №2 — инструкция по запуску

# 

# \## Состав репозитория

# 

# | Путь | Назначение |

# |------|------------|

# | `data/mock\_data1.csv` … `mock\_data10.csv` | Исходные данные (10 × 1000 строк) |

# | `docker-compose.yml` | PostgreSQL, Spark, ClickHouse |

# | `sql/postgres/` | Схема staging/dw и загрузка CSV |

# | `sql/clickhouse/` | DDL для 6 витрин |

# | `spark/jobs/` | Spark-джобы ETL и отчётов |

# | `spark/lib/` | Общая логика ETL и построения витрин |

# 

# \## Требования

# 

# Docker Desktop

# 

# \## Запуск

# 

# Подробнее см. `README.md`.

