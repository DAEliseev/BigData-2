$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$env:COMPOSE_ANSI = "never"

$JarsPath = "/opt/spark/jars/postgresql-42.7.3.jar,/opt/spark/jars/clickhouse-jdbc-0.6.3-all.jar"

$SparkSubmitArgs = @(
    "--master", "local[*]",
    "--driver-memory", "2g",
    "--conf", "spark.ui.enabled=false",
    "--conf", "spark.log.level=ERROR",
    "--conf", "spark.driver.extraJavaOptions=-Dlog4j2.configurationFile=file:/opt/spark/conf/log4j2-quiet.properties",
    "--jars", $JarsPath
)

function Invoke-Psql {
    param([string]$Query)
    docker exec lab2-postgres psql -U lab -d labdb -tAc $Query 2>$null
}

function Invoke-ClickHouse {
    param([string]$Query)
    docker exec lab2-clickhouse clickhouse-client --user lab --password lab --query $Query 2>$null
}

Write-Host "Starting Docker containers..."
docker compose up -d --quiet-pull 2>$null | Out-Null

Write-Host "Waiting for PostgreSQL and CSV load..."
while ($true) {
    $count = Invoke-Psql "SELECT COUNT(*) FROM staging.mock_data;"
    if ($count -eq "10000") { break }
    Start-Sleep -Seconds 2
}

Write-Host "Running Spark ETL..."
docker exec lab2-spark /opt/spark/bin/spark-submit @SparkSubmitArgs /opt/spark-jobs/01_etl_star_schema.py 2>&1 | Out-Null

Write-Host "Running Spark reports..."
docker exec lab2-spark /opt/spark/bin/spark-submit @SparkSubmitArgs /opt/spark-jobs/02_reports_clickhouse.py 2>&1 | Out-Null

Write-Host ""
Write-Host "=== Verification ==="
Write-Host ("staging.mock_data rows:     {0}" -f (Invoke-Psql "SELECT COUNT(*) FROM staging.mock_data;"))
Write-Host ("dw.fact_sales rows:         {0}" -f (Invoke-Psql "SELECT COUNT(*) FROM dw.fact_sales;"))
Write-Host ("dw.dim_product rows:        {0}" -f (Invoke-Psql "SELECT COUNT(*) FROM dw.dim_product;"))
Write-Host ("ClickHouse mart tables:     {0}" -f (Invoke-ClickHouse "SELECT count() FROM system.tables WHERE database = 'labdb' AND name LIKE 'mart_%';"))
Write-Host ("mart_product_sales rows:    {0}" -f (Invoke-ClickHouse "SELECT count() FROM labdb.mart_product_sales;"))
Write-Host ""
Write-Host "Expected: mock_data=10000, fact_sales=10000, dim_product=1000, mart tables=6, mart rows>=1"
Write-Host ""

Write-Host "PostgreSQL interactive check (exit: \q)"
docker exec -it lab2-postgres psql -U lab -d labdb

Write-Host ""
Write-Host "Stopping containers..."
docker compose down 2>$null | Out-Null
Write-Host "Done."