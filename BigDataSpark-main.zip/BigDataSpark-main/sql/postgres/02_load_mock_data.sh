#!/bin/bash
set -euo pipefail

echo "Loading mock_data CSV files into staging.mock_data..."

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    TRUNCATE staging.mock_data RESTART IDENTITY;
EOSQL

for i in $(seq 1 10); do
    file="/data/mock_data${i}.csv"
    if [ ! -f "$file" ]; then
        echo "Missing file: $file"
        exit 1
    fi
    echo "Importing $file (source_file=${i})"
    psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
        TRUNCATE staging.csv_import;
        \\copy staging.csv_import FROM '${file}' WITH (FORMAT csv, HEADER true, NULL '');
        INSERT INTO staging.mock_data (
            source_file, id,
            customer_first_name, customer_last_name, customer_age, customer_email,
            customer_country, customer_postal_code, customer_pet_type, customer_pet_name,
            customer_pet_breed, seller_first_name, seller_last_name, seller_email,
            seller_country, seller_postal_code, product_name, product_category,
            product_price, product_quantity, sale_date, sale_customer_id, sale_seller_id,
            sale_product_id, sale_quantity, sale_total_price, store_name, store_location,
            store_city, store_state, store_country, store_phone, store_email, pet_category,
            product_weight, product_color, product_size, product_brand, product_material,
            product_description, product_rating, product_reviews, product_release_date,
            product_expiry_date, supplier_name, supplier_contact, supplier_email,
            supplier_phone, supplier_address, supplier_city, supplier_country
        )
        SELECT
            ${i}, id,
            customer_first_name, customer_last_name, customer_age, customer_email,
            customer_country, customer_postal_code, customer_pet_type, customer_pet_name,
            customer_pet_breed, seller_first_name, seller_last_name, seller_email,
            seller_country, seller_postal_code, product_name, product_category,
            product_price, product_quantity,
            to_date(sale_date, 'MM/DD/YYYY'),
            sale_customer_id, sale_seller_id, sale_product_id, sale_quantity, sale_total_price,
            store_name, store_location, store_city, store_state, store_country,
            store_phone, store_email, pet_category, product_weight, product_color,
            product_size, product_brand, product_material, product_description,
            product_rating, product_reviews,
            to_date(product_release_date, 'MM/DD/YYYY'),
            to_date(product_expiry_date, 'MM/DD/YYYY'),
            supplier_name, supplier_contact, supplier_email, supplier_phone,
            supplier_address, supplier_city, supplier_country
        FROM staging.csv_import;
EOSQL
done

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    SELECT COUNT(*) AS mock_data_rows FROM staging.mock_data;
EOSQL
