CREATE DATABASE IF NOT EXISTS labdb;

CREATE TABLE IF NOT EXISTS labdb.mart_product_sales
(
    generated_at DateTime DEFAULT now(),
    top10_products String,
    revenue_by_category String,
    product_ratings String
)
ENGINE = MergeTree
ORDER BY generated_at;

CREATE TABLE IF NOT EXISTS labdb.mart_customer_sales
(
    generated_at DateTime DEFAULT now(),
    top10_customers String,
    customers_by_country String,
    avg_check_per_customer String
)
ENGINE = MergeTree
ORDER BY generated_at;

CREATE TABLE IF NOT EXISTS labdb.mart_time_sales
(
    generated_at DateTime DEFAULT now(),
    monthly_yearly_trends String,
    revenue_period_comparison String,
    avg_order_size_by_month String
)
ENGINE = MergeTree
ORDER BY generated_at;

CREATE TABLE IF NOT EXISTS labdb.mart_store_sales
(
    generated_at DateTime DEFAULT now(),
    top5_stores String,
    sales_by_city_country String,
    avg_check_per_store String
)
ENGINE = MergeTree
ORDER BY generated_at;

CREATE TABLE IF NOT EXISTS labdb.mart_supplier_sales
(
    generated_at DateTime DEFAULT now(),
    top5_suppliers String,
    avg_price_by_supplier String,
    sales_by_supplier_country String
)
ENGINE = MergeTree
ORDER BY generated_at;

CREATE TABLE IF NOT EXISTS labdb.mart_product_quality
(
    generated_at DateTime DEFAULT now(),
    rating_extremes String,
    rating_sales_correlation String,
    most_reviewed_products String
)
ENGINE = MergeTree
ORDER BY generated_at;
